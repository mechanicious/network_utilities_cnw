#Build

1. ``npm install``
2. ``webpack -w``

#Usage

Open `index.html` after building.